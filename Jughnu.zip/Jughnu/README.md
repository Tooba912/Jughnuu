# 👗 Jughnu - Clothing Store Website

**Jughnu** is a modern and responsive frontend website for a clothing store, designed using **HTML, CSS, and JavaScript**. It features product listings, shopping cart functionality, category filters, and an attractive user interface.

## 🌟 Features

- 🛍️ Four main categories: Clothing, Shoes, Bags, Accessories
- 👗 Each category displays 3+ products with:
  - Image
  - Price
  - “Add to Cart” and “Buy Now” buttons
- 🛒 Cart system with:
  - Quantity adjustment (+ / -)
  - Total price calculation
  - Cart icon with live item count in the top-right corner
- 📱 Fully responsive layout for mobile, tablet, and desktop

## 🧰 Technologies Used

- **HTML5**
- **CSS3** (including Flexbox/Grid)
- **JavaScript** (DOM manipulation, cart logic)

## 📁 Folder Structure

